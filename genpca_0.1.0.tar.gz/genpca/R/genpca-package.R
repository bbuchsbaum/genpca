## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib genpca, .registration = TRUE
## usethis namespace: end
NULL
