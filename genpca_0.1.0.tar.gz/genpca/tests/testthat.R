library(testthat)
library(genpca)

test_check("genpca")
